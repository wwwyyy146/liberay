package com.rabbiter.library.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.rabbiter.library.entity.SysReader;

public interface SysRoleMapper extends BaseMapper<SysReader.SysRole> {
}
