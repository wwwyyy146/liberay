package com.rabbiter.library.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.rabbiter.library.entity.SysNotice;

public interface SysNoticeMapper extends BaseMapper<SysNotice> {
}
