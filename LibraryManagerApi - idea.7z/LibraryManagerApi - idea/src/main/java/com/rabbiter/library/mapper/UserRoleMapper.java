package com.rabbiter.library.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.rabbiter.library.entity.UserRole;

public interface UserRoleMapper extends BaseMapper<UserRole> {
}
