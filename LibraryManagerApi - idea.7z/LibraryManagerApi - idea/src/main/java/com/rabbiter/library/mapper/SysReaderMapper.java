package com.rabbiter.library.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.rabbiter.library.entity.SysReader;

public interface SysReaderMapper extends BaseMapper<SysReader> {
}
