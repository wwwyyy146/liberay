package com.rabbiter.library.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.rabbiter.library.entity.ReaderRole;

public interface ReaderRoleService extends IService<ReaderRole> {
}
